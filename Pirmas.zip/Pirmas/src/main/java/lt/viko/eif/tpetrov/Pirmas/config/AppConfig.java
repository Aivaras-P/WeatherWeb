package lt.viko.eif.tpetrov.Pirmas.config;

public class AppConfig {
}
